﻿Module Module1
    Public strUser As String
    Public intUser As Integer
    Public dblSubtotal As Double
    Public dblModelPrice As Double
    Public dblExtras As Double
    Public dblQuantity As Double
    Public dblLogo As Double
    Public dblQuarter As Double
    Public dblVamp As Double
    Public dblEyestay As Double
    Public dblHeeltab As Double
    Public dblHeelBackCounter As Double
    Public dblLaces As Double
    Public strModel As String
    Public blQuarter As Boolean
    Public strQuarterCol As String
    Public blVamp As Boolean
    Public strVampCol As String
    Public blEyestay As Boolean
    Public strEyestayCol As String
    Public blHeelTab As Boolean
    Public strHeelTabCol As String
    Public blHeelBackCounter As Boolean
    Public strHeelBackCounterCol As String
    Public blLaces As Boolean
    Public strLacesCol As String

End Module
